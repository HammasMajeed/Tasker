import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maintenance-report',
  templateUrl: './maintenance-report.page.html',
  styleUrls: ['./maintenance-report.page.scss'],
})
export class MaintenanceReportPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
